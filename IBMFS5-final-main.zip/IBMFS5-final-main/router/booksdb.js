let books = {
  9780441013593: { author: "Frank Herbert", title: "Dune", reviews: {} },
  9780684833392: { author: "Joseph Heller", title: "Catch-22", reviews: {} },
  9780679417392: { author: "George Orwell", title: "1984", reviews: {} },
  9780345363008: {
    author: "Terry Brooks",
    title: "The Talismans of Shannara",
    reviews: {},
  },
  9780440418320: {
    author: "Philip Pullman",
    title: "The Golden Compass",
    reviews: {},
  },
  9780679879251: {
    author: "Philip Pullman",
    title: "The Subtle Knife",
    reviews: {},
  },
  9780194237628: {
    author: "Jane Austen",
    title: "Pride and Prejudice",
    reviews: {},
  },
  9781451635621: {
    author: "Margaret Mitchell",
    title: "Gone With the Wind",
    reviews: {},
  },
  9780142005149: {
    author: "Charlotte Brontë",
    title: "Jane Eyre",
    reviews: {},
  },
  9780194237611: {
    author: "Emily Brontë",
    title: "Wuthering Heights",
    reviews: {},
  },
  9780895773227: {
    author: "Herman Melville",
    title: "Moby Dick",
    reviews: {},
  },
  9780141439563: {
    author: "Charles Dickens",
    title: "Great Expectations",
    reviews: {},
  },
  9780679720201: {
    author: "Albert Camus",
    title: "The Stranger",
    reviews: {},
  },
  9780140439441: {
    author: "Charles Dickens",
    title: "David Copperfield",
    reviews: {},
  },
  9780140049978: {
    author: "John Steinbeck",
    title: "East of Eden",
    reviews: {},
  },
  9781593080051: {
    author: "Mary Shelley",
    title: "Frankenstein",
    reviews: {},
  },
  9780385333481: {
    author: "Kurt Vonnegut",
    title: "Cat's Cradle",
    reviews: {},
  },
  9780517542095: {
    author: "Douglas Adams",
    title: "The Hitchhiker's Guide to the Galaxy",
    reviews: {},
  },
  9780451191144: {
    author: "Ayn Rand",
    title: "Atlas Shrugged",
    reviews: {},
  },
};

module.exports = books;
